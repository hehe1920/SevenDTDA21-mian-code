﻿using SevenDTDMono;
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;

public class AssemblyHelper : IDisposable
{
    private static List<string> assembliesToLoad;
    private AppDomain assemblyDomain = AppDomain.CreateDomain("AssemblyDomain");
    private static Dictionary<string, Assembly> loadedAssemblies = new Dictionary<string, Assembly>();
    private List<Assembly> loadedAssembliesList = new List<Assembly>();

    static AssemblyHelper()
    {
        List<string> list1 = new List<string> { 
            "0Harmony",
            "MonoMod.Utils",
            "UniverseLib.mono",
            "UnityExplorer.STANDALONE.Mono"
        };
        assembliesToLoad = list1;
    }

    public bool AreAllAssembliesLoaded()
    {
        foreach (string str in assembliesToLoad)
        {
            if (!IsAssemblyLoaded(str))
            {
                return false;
            }
        }
        return true;
    }

    public void Dispose()
    {
        foreach (Assembly assembly in this.loadedAssembliesList)
        {
            AppDomain.Unload(this.assemblyDomain);
        }
        this.assemblyDomain = null;
    }

    private static bool IsAssemblyLoaded(string assemblyName) => 
        loadedAssemblies.ContainsKey(assemblyName);

    public bool IsAssemblyLoaded1(string assemblyName) => 
        this.loadedAssembliesList.Exists(assembly => assembly.GetName().Name.Equals(assemblyName));

    public void LoadAndExecuteAssembly(string assemblyPath)
    {
        Assembly item = this.assemblyDomain.Load(AssemblyName.GetAssemblyName(assemblyPath));
        this.loadedAssembliesList.Add(item);
    }

    private static void LoadAssembly(string assemblyName)
    {
        if (IsAssemblyLoaded(assemblyName))
        {
            Log.Out(assemblyName + " is already loaded.");
        }
        else
        {
            string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "load", assemblyName + ".dll");
            if (File.Exists(path))
            {
                Assembly assembly = Assembly.LoadFrom(path);
                loadedAssemblies[assemblyName] = assembly;
                Log.Out(assemblyName + " has been loaded.");
            }
            else
            {
                Log.Out(assemblyName + " is not present at location: " + path);
                Settings.ASMPreload = false;
            }
        }
    }

    public void TryLoad()
    {
        if (assembliesToLoad != null)
        {
            foreach (string str in assembliesToLoad)
            {
                LoadAssembly(str);
            }
        }
    }

    public void UnloadAssembly(string assemblyName)
    {
        Assembly item = this.loadedAssembliesList.Find(assembly => assembly.GetName().Name.Equals(assemblyName));
        if (item != null)
        {
            AppDomain.Unload(this.assemblyDomain);
            this.assemblyDomain = AppDomain.CreateDomain("AssemblyDomain");
            this.loadedAssembliesList.Remove(item);
        }
    }
}

