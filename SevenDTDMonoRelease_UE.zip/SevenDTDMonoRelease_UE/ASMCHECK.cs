﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;

public class ASMCHECK
{
    private static List<string> assembliesToCheck;

    static ASMCHECK()
    {
        List<string> list1 = new List<string> { 
            "SevenDTDMono",
            "0Harmony",
            "MonoMod.Utils",
            "UniverseLib.mono",
            "UnityExplorer.STANDALONE.Mono"
        };
        assembliesToCheck = list1;
    }

    public static bool CheckLoadedAssemblies()
    {
        List<string> list = (from assembly in AppDomain.CurrentDomain.GetAssemblies() select assembly.GetName().Name.ToLower()).ToList<string>();
        foreach (string str in assembliesToCheck)
        {
            string item = str.ToLower();
            if (!list.Contains(item))
            {
                Log.Out("Assembly '" + str + "' is not loaded.");
                return false;
            }
            Log.Out("Assembly '" + str + "' is loaded.");
        }
        return true;
    }

    public static void CheckLoadedAssemblies1()
    {
        string[] source = (from assembly in AppDomain.CurrentDomain.GetAssemblies() select assembly.GetName().Name.ToLower()).ToArray<string>();
        foreach (string str in assembliesToCheck)
        {
            string str2 = str.ToLower();
            if (source.Contains<string>(str2))
            {
                Log.Out("Assembly '" + str + "' is loaded.");
            }
            else
            {
                Log.Out("Assembly '" + str + "' is not loaded.");
            }
        }
    }

    [Serializable, CompilerGenerated]
    private sealed class <>c
    {
        public static readonly ASMCHECK.<>c <>9 = new ASMCHECK.<>c();
        public static Func<Assembly, string> <>9__1_0;
        public static Func<Assembly, string> <>9__2_0;

        internal string <CheckLoadedAssemblies>b__1_0(Assembly assembly) => 
            assembly.GetName().Name.ToLower();

        internal string <CheckLoadedAssemblies1>b__2_0(Assembly assembly) => 
            assembly.GetName().Name.ToLower();
    }
}

