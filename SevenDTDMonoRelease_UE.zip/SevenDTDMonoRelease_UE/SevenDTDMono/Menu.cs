﻿namespace SevenDTDMono
{
    using System;
    using UnityEngine;

    public class Menu : MonoBehaviour
    {
        private void OnGUI()
        {
        }

        private void Start()
        {
        }

        private void Update()
        {
        }
    }
}

