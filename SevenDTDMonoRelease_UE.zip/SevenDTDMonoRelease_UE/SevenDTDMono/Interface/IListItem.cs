﻿namespace SevenDTDMono.Interface
{
    using System;

    public interface IListItem
    {
        string Name { get; }
    }
}

