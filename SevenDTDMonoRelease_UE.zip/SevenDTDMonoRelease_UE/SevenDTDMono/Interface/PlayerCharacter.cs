﻿namespace SevenDTDMono.Interface
{
    using System;
    using System.Runtime.CompilerServices;

    public class PlayerCharacter : IListItem
    {
        public string Name { get; set; }
    }
}

