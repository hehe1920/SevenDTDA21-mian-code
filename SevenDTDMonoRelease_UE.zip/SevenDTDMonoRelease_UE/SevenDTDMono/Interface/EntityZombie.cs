﻿namespace SevenDTDMono.Interface
{
    using System;
    using System.Runtime.CompilerServices;

    public class EntityZombie : IListItem
    {
        public string Name { get; set; }
    }
}

