﻿using System;

public static class DictionaryExtensions
{
}

