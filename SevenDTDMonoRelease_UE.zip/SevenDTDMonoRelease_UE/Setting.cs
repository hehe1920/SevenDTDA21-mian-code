﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

internal class Setting
{
    public static Color _cidle;
    public static Color _cOFF;
    public static Color _cON;
    public static float _FL_APM;
    public static float _FL_blokdmg;
    public static float _FL_dmg;
    public static float _FL_harvest;
    public static float _FL_jmp;
    public static float _FL_killdmg;
    public static float _FL_run;
    public static bool aimbot;
    public static bool ASMloaded;
    public static bool ASMPreload;
    public static GUIStyle BgStyle;
    public static UnityEngine.UI.Text BOOLText;
    public static GUIStyle BtnStyle;
    public static GUIStyle BtnStyle1;
    public static GUIStyle BtnStyle2;
    public static GUIStyle BtnStyle3;
    public static Dictionary<string, BuffClass>.KeyCollection buffsDict;
    public static Dictionary<string, bool> ButtonTState = new Dictionary<string, bool>();
    public static bool chams;
    public static bool cm;
    internal static bool crosshair;
    public static bool drpbp;
    public static bool fovCircle;
    public static Dictionary<int, bool> IB = new Dictionary<int, bool>();
    public static bool infiniteAmmo;
    public static bool IsGameStarted;
    public static bool IsVarsLoaded;
    public static GUIStyle LabelStyle;
    public static bool magicBullet;
    public static Dictionary<string, bool> MenuDropTState = new Dictionary<string, bool>();
    public static bool noWeaponBob;
    public static GUIStyle OffStyle;
    public static bool onht;
    public static GUIStyle OnStyle;
    public static bool playerBox;
    public static bool PlayerBox;
    internal static bool playerCornerBox;
    public static bool playerHealth;
    public static bool playerName;
    public static bool PlayerName;
    public static Dictionary<PassiveEffects, bool> PVETState = new Dictionary<PassiveEffects, bool>();
    public static Dictionary<string, bool> RB = new Dictionary<string, bool>();
    private static List<string> ResetBools;
    public static Dictionary<string, bool> SB = new Dictionary<string, bool>();
    public static Dictionary<string, bool> SB1;
    internal static bool selfDestruct;
    public static Dictionary<string, float> SF = new Dictionary<string, float>();
    public static bool speed;
    public static Dictionary<string, string> SS = new Dictionary<string, string>();
    private static List<string> StaticBools;
    public static Dictionary<string, Vector2> SV2;
    public static string Text;
    public static GUIStyle ToggStyle1;
    public static GUIStyle ToggStyle2;
    private static List<string> VarStringBools;
    public static Dictionary<string, bool> VSB = new Dictionary<string, bool>();
    public static bool zombieBox;
    public static bool zombieCornerBox;
    public static bool zombieHealth;
    public static bool zombieName;

    static Setting()
    {
        Dictionary<string, bool> dictionary1 = new Dictionary<string, bool> {
            { 
                "FoldBuff",
                false
            },
            { 
                "FoldCBuff",
                false
            },
            { 
                "FoldPassive",
                false
            },
            { 
                "FoldPGV",
                false
            },
            { 
                "FoldPlayer",
                false
            },
            { 
                "FoldZombie",
                false
            },
            { 
                "foldout1",
                false
            },
            { 
                "foldout2",
                false
            },
            { 
                "foldout3",
                false
            },
            { 
                "foldout4",
                false
            },
            { 
                "foldout5",
                false
            }
        };
        SB1 = dictionary1;
        Dictionary<string, Vector2> dictionary2 = new Dictionary<string, Vector2>();
        Vector2 vector = new Vector2();
        dictionary2.Add("scrollPlayer", vector);
        vector = new Vector2();
        dictionary2.Add("scrollBuff", vector);
        vector = new Vector2();
        dictionary2.Add("scrollCBuff", vector);
        vector = new Vector2();
        dictionary2.Add("scrollZombie", vector);
        vector = new Vector2();
        dictionary2.Add("scrollPassive", vector);
        vector = new Vector2();
        dictionary2.Add("scrollPGV", vector);
        dictionary2.Add("scrollKill", new Vector2());
        dictionary2.Add("ScrollMenu0", Vector2.zero);
        dictionary2.Add("ScrollMenu1", Vector2.zero);
        dictionary2.Add("ScrollMenu2", Vector2.zero);
        dictionary2.Add("ScrollMenu3", Vector2.zero);
        dictionary2.Add("ScrollMenu4", Vector2.zero);
        dictionary2.Add("ScrollMenu5", Vector2.zero);
        dictionary2.Add("scrollBuffBTN", Vector2.zero);
        SV2 = dictionary2;
        List<string> list1 = new List<string> { 
            "NSCAMBLE",
            "NSCAMBLE1",
            "_nameScramble",
            "IsGameMainMenu",
            "IsGameStarted",
            "IsVarsLoaded",
            "hasStartedOnce",
            "BoolReset"
        };
        StaticBools = list1;
        List<string> list2 = new List<string> { 
            "Cheatbuff",
            "BuffClasses",
            "Cbuff",
            "PGV"
        };
        VarStringBools = list2;
        List<string> list3 = new List<string> { 
            "first",
            "second",
            "third",
            "NSCRAM1",
            "NSCRAM2",
            "_trystackitems",
            "_InstantLoot",
            "_instantScrap",
            "_instantCraft",
            "_instantSmelt",
            "_infDurability",
            "fovCircle",
            "_isEditmode",
            "_QuestComplete",
            "_EtraderOpen",
            "_LOQuestRewards",
            "_healthNstamina",
            "_foodNwater",
            "_ignoreByAI",
            "_NoBadBuff",
            "_BL_Harvest",
            "_BL_Blockdmg",
            "_BL_Kill",
            "_BL_Run",
            "_BL_Jmp",
            "_BL_APM",
            "reloadBuffs",
            "CmDm",
            "drawDebug"
        };
        ResetBools = list3;
        PlayerBox = false;
        PlayerName = false;
        playerName = false;
        zombieName = false;
        playerBox = false;
        zombieBox = false;
        crosshair = false;
        playerCornerBox = false;
        zombieCornerBox = false;
        zombieHealth = false;
        playerHealth = false;
        chams = false;
        fovCircle = false;
        selfDestruct = false;
        ASMloaded = false;
        ASMPreload = false;
        _FL_dmg = 0.5f;
        _FL_run = 0.5f;
        _FL_jmp = 0.5f;
        _FL_killdmg = 0.5f;
        _FL_blokdmg = 0.5f;
        _FL_harvest = 2f;
        _FL_APM = 2f;
        Text = "Text";
        _cON = Color.green;
        _cOFF = Color.red;
        _cidle = Color.red;
    }

    public static bool GC(Dictionary<string, bool> dictionary, string key)
    {
        bool flag;
        if (dictionary.TryGetValue(key, out flag))
        {
            return flag;
        }
        dictionary.Add(key, false);
        return false;
    }

    public static void initBools()
    {
        foreach (string str in StaticBools)
        {
            if (!SB.ContainsKey(str))
            {
                SB.Add(str, false);
            }
        }
        foreach (string str2 in VarStringBools)
        {
            if (!VSB.ContainsKey(str2))
            {
                VSB.Add(str2, false);
            }
        }
        foreach (string str3 in ResetBools)
        {
            if (!RB.ContainsKey(str3))
            {
                RB.Add(str3, false);
            }
        }
    }

    public static void initReset()
    {
        if (SB["BoolReset"])
        {
            foreach (string str in ResetBools)
            {
                if (RB.ContainsKey(str))
                {
                    RB[str] = false;
                }
            }
            SB["BoolReset"] = false;
        }
    }

    public static void Styles()
    {
        if (BgStyle == null)
        {
            BgStyle = new GUIStyle();
            BgStyle.normal.textColor = Color.white;
            BgStyle.onNormal.textColor = Color.white;
            BgStyle.active.textColor = Color.white;
            BgStyle.onActive.textColor = Color.white;
        }
        if (LabelStyle == null)
        {
            LabelStyle = new GUIStyle();
            LabelStyle.normal.textColor = Color.white;
            LabelStyle.onNormal.textColor = Color.white;
            LabelStyle.active.textColor = Color.white;
            LabelStyle.onActive.textColor = Color.white;
        }
        if (OffStyle == null)
        {
            OffStyle = new GUIStyle();
            OffStyle.normal.textColor = Color.white;
            OffStyle.onNormal.textColor = Color.white;
            OffStyle.active.textColor = Color.white;
            OffStyle.onActive.textColor = Color.white;
        }
        if (OnStyle == null)
        {
            OnStyle = new GUIStyle();
            OnStyle.normal.textColor = Color.white;
            OnStyle.onNormal.textColor = Color.white;
            OnStyle.active.textColor = Color.white;
            OnStyle.onActive.textColor = Color.white;
        }
        if (BtnStyle == null)
        {
            BtnStyle = new GUIStyle();
            BtnStyle.normal.textColor = Color.white;
            BtnStyle.onNormal.textColor = Color.white;
            BtnStyle.active.textColor = Color.white;
            BtnStyle.onActive.textColor = Color.white;
        }
        if (BtnStyle1 == null)
        {
            BtnStyle1 = new GUIStyle();
            BtnStyle1.normal.textColor = _cOFF;
            BtnStyle1.onNormal.textColor = _cOFF;
            BtnStyle1.active.textColor = _cON;
            BtnStyle1.onActive.textColor = _cON;
            BtnStyle1.onHover.textColor = Color.yellow;
        }
        if (ToggStyle1 == null)
        {
            ToggStyle1 = new GUIStyle();
            ToggStyle1.onHover.textColor = Color.yellow;
            ToggStyle1.alignment = TextAnchor.MiddleRight;
        }
    }
}

